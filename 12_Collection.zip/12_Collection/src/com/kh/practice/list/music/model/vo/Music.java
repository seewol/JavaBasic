package com.kh.practice.list.music.model.vo;

public class Music {

}
