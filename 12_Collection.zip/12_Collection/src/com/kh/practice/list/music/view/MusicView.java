package com.kh.practice.list.music.view;

import java.util.Scanner;

import com.kh.practice.list.music.controller.MusicController;

public class MusicView {
		Scanner sc = new Scanner(System.in);
		MusicController mc = new MusicController();
		
		public void mainMenu() {
			
		}
		
		public void addList() {
			
		}
		
		public void addAtZero() {
			
		}
		
		public void printAll() {
			
		}
		
		public void searchMusic() {
			
		}
		
		public void removeMusic() {
			
		}
		public void setMusic() {
			
		}
		
}
