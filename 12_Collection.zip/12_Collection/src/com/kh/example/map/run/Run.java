package com.kh.example.map.run;

import com.kh.example.map.controller.MapController;

public class Run {
	public static void main(String[] args) {
		MapController mc = new MapController();
//		mc.doMap();
//		mc.doProperties();
//		mc.fileSave();
//		mc.fileOpen();
		mc.fileSave2();
		mc.fileOpen2();
	}
}
