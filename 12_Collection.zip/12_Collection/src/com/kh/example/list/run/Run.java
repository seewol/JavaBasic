package com.kh.example.list.run;

import com.kh.example.list.controller.ListController;

public class Run {
	public static void main(String[] args) {
		new ListController().doList();
	}
}
