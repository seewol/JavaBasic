package com.kh.example.set.run;

import com.kh.example.set.controller.SetController;

public class Run {
	public static void main(String[] args) {
		new SetController().doSet();
	}
}
